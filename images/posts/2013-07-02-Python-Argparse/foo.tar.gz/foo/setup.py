from setuptools import setup, find_packages
import sys, os

version = '0.1'

setup(name='foo',
      version=version,
      description="foo",
      long_description="""\
hang a man""",
      classifiers=[], # Get strings from http://pypi.python.org/pypi?%3Aaction=list_classifiers
      keywords='foo bar',
      author='chalupaul',
      author_email='me@chalupaul.com',
      url='chalupaul.com',
      license='',
      packages=find_packages(exclude=['ez_setup', 'examples', 'tests']),
      include_package_data=True,
      zip_safe=False,
      install_requires=[
          # -*- Extra requirements: -*-
      ],
      entry_points = {
        'console_scripts': [
            'foo = foo.foo:main'
        ]
      }
      ,
      )
