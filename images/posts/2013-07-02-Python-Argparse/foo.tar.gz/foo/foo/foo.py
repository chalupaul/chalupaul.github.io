import sys
import argparse
def main():
    try:
        f = Foo()
        f.main()
    except Exception as e:
        print(e, file=sys.stderr)
        sys.exit(1)

class Foo(object):

    def __init__(self):
        self.init_parser()

    def main(self):
        print(self.args)

    def init_parser(self):
        parser = argparse.ArgumentParser(
            prog='foo',
            description='hi, i am a description',
            epilog='hi there, i\'m an epilog'
        )
        parser_subs = parser.add_subparsers()
        parser_user = parser_subs.add_parser('user', help='manage users')
        parser_user_subs = parser_user.add_subparsers()

        parser_user_create = parser_user_subs.add_parser('create', 
                                                         help='create user')
        parser_user_create.add_argument('--name', help='specify user name')
        parser_user_create.add_argument('--age', help='specify user age')
        parser_user_create.add_argument('-user_action',
                                      help=argparse.SUPPRESS,
                                      default='create')


        parser_user_delete = parser_user_subs.add_parser('delete', 
                                                         help='delete user')
        parser_user_delete.add_argument('--name', help='name to delete')
        parser_user_delete.add_argument('-user_action',
                                      help=argparse.SUPPRESS,
                                      default='delete')

        parser_user_list = parser_user_subs.add_parser('list', 
                                                       help='list users')
        parser_user_list.add_argument('-user_action', 
                                      help=argparse.SUPPRESS, 
                                      default='list')





        self.args = vars(parser.parse_args())


        

